const CMC = "https://pro-api.coinmarketcap.com/public-api";
const BINANCE = "https://api.binance.com";
const BINANCE_DATA = "https://data-api.binance.vision";
const FUTURES = "https://fapi.binance.com";

async function jsonFetch(url, init={}) {
  const r = await fetch(url, init);
  const text = await r.text();
  let data;
  try { data = JSON.parse(text); } catch { data = {error:text}; }
  if (!r.ok) return new Response(JSON.stringify({error:"upstream",status:r.status,data}), {status:r.status,headers:{"content-type":"application/json"}});
  return Response.json(data, {headers:{"cache-control":"no-store"}});
}

export default {
  async fetch(request, env) {
    const u = new URL(request.url);
    if (u.pathname === "/api/universe") {
      const page = Math.max(1, Math.min(3, Number(u.searchParams.get("page")||1)));
      const start = page===1 ? 1 : page===2 ? 101 : 201;
      const target = `${CMC}/v3/cryptocurrency/listings/latest?start=${start}&limit=100&convert=USD`;
      return jsonFetch(target, {headers:{"Accept":"application/json"}});
    }

    if (u.pathname === "/api/binance/ticker") {
      return jsonFetch(`${BINANCE_DATA}/api/v3/ticker/24hr`);
    }
    if (u.pathname === "/api/binance/exchangeInfo") {
      return jsonFetch(`${BINANCE_DATA}/api/v3/exchangeInfo`);
    }

    const spot = u.pathname.match(/^\/api\/binance(\/.*)$/);
    if (spot) {
      const qs = u.search;
      return jsonFetch(`${BINANCE_DATA}${spot[1]}${qs}`);
    }

    const fut = u.pathname.match(/^\/api\/futures(\/.*)$/);
    if (fut) {
      return jsonFetch(`${FUTURES}${fut[1]}${u.search}`);
    }

    // Serve the real UI.
    return env.ASSETS.fetch(request);
  }
};
