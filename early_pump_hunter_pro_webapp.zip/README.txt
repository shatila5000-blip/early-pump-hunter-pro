# Early Pump Hunter PRO — Web App

این نسخه برای حل مشکل `content://` ساخته شده است.
Front-end دیگر مستقیماً به CoinMarketCap/Binance وصل نمی‌شود؛
درخواست‌ها از `/api/*` به Worker می‌روند و Worker از سمت سرور داده واقعی را می‌گیرد.

## استقرار پیشنهادی

### Cloudflare Workers
1. یک پروژه Workers بسازید.
2. فایل‌های این پوشه را در پروژه قرار دهید.
3. با Wrangler deploy کنید:
   `npx wrangler deploy`
4. آدرس `https://...workers.dev` را با موبایل باز کنید.

Cloudflare Workers از static assets و Worker API در یک پروژه پشتیبانی می‌کند.

### اگر GitHub دارید
کل این پوشه را در یک repository قرار دهید و با Cloudflare متصل کنید.

## داده‌ها
- Top 300: CoinMarketCap Keyless Public API
- Spot market / OHLCV / aggregate trades: Binance public market data
- Futures Funding / OI: Binance Futures public endpoints

## نکته
این نسخه هیچ Demo Data ندارد. اگر یک منبع upstream موقتاً محدود شود، همان بخش خطا می‌دهد و داده ساختگی تولید نمی‌کند.
